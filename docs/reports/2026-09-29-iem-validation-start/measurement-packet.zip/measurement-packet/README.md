# IEM measurement packet

10 drivers, 133 planned configurations. No physical measurements are included.

Start with Sonion 2356. The guide-geometry cases define damper positions for new bench tests; the original published example does not identify its damper position.

Use the protocol in docs/IEM_VALIDATION_PROTOCOL.md. Record the actual coupler and geometry before collecting data. Review the receiver/transformer ratings before applying the proposed voltage. The generated fixture is a model assumption, not proof of the manufacturer's fixture.

Keep fit and validation cases separate. Fit using only fit cases; freeze the final model and regenerate a NEW packet before measuring held-out validation cases. Never overwrite measurement records. Copy a completed template into measurements/ at the path named in manifest.json. Duplicate case IDs/files for each specimen and remount, updating damping pair IDs accordingly.

The default packet covers a pilot band only. Shared bores, complete IEMs, extended-frequency EST performance, and distortion need additional physical tests. The report does not certify those capabilities.
